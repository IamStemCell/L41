from django import forms



class NoteForm(forms.Form):
    title = forms.CharField(label='Title', max_length=100)
    text = forms.CharField(label='Text', widget=forms.Textarea)
    reminder = forms.DateTimeField(label='Reminder', required=False, widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}))
    category = forms.CharField(label='Category', max_length=50, required=False)
